package com.example.add2num;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {


    EditText num1;
    EditText num2;
    Button add;
    TextView res;
    Intent intent;
    Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intent=new Intent(this,MainActivity2.class);
        extras=new Bundle();
        String colorString="red";

        String TAG="MainActivity";
        num1=findViewById(R.id.num1);
        num2=findViewById(R.id.num2);
        add=findViewById(R.id.add);
        res=findViewById(R.id.res);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n=Integer.parseInt(num1.getText().toString());
                int m=Integer.parseInt(num2.getText().toString());
                int c;

                c=n+m;
                res.setText("Result is: "+ c);

                extras.putString("num1",n+"");
                extras.putString("num2",m+"");
                extras.putString("num3",c+"");
                extras.putString("color",colorString);
                intent.putExtras(extras);
                startActivity(intent);


//                Log.i(TAG,"1st number is :"+n);
//                Log.i(TAG,"2nd number is :"+m);
//                Log.i(TAG, "result is :"+c);
//
//                Toast.makeText(getApplicationContext(), "onclick: Invoked", Toast.LENGTH_LONG).show();
//                Log.i(TAG,"onclick has displayed");




            }
        });
    }
}


