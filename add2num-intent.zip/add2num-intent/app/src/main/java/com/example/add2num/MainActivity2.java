package com.example.add2num;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity{
    Intent intent;
    String TAG="MainActivity";
    TextView num1;
    TextView num2;
    TextView res;
    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        num1=findViewById(R.id.textView6);
        num2=findViewById(R.id.textView3);
        res=findViewById(R.id.textView7);
        intent=getIntent();

        Bundle extras=intent.getExtras();
        String n1=extras.getString("num1");
        String n2=extras.getString("num2");
        String n3=extras.getString("num3");
        String color = extras.getString("color","blue");

        num1.setText("number 1 is:"+n1);
        num2.setText("number 2 is:"+n2);
        res.setText("number 3 is:"+n3);

    }
}
